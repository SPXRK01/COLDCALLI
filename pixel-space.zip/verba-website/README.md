# VERBA - 2025 Presentation Branding Design

A modern, responsive website showcasing the VERBA brand identity with cutting-edge animations and dark theme design.

## Features

- **Modern Dark Theme** with vibrant green accents
- **Smooth Animations** powered by Framer Motion
- **Fully Responsive** design for all screen sizes
- **Modern Typography** using Helvetica font family
- **Interactive Elements** with hover effects and micro-interactions
- **Optimized Performance** with Vite build system

## Tech Stack

- **Frontend**: React 18 + TypeScript + Vite
- **Styling**: TailwindCSS 3 with custom design system
- **Animations**: Framer Motion
- **Build Tool**: Vite
- **Package Manager**: npm

## Quick Start

1. **Install dependencies**:

   ```bash
   npm install
   ```

2. **Start development server**:

   ```bash
   npm run dev
   ```

3. **Open in browser**:
   Navigate to `http://localhost:8080`

## Available Scripts

- `npm run dev` - Start development server
- `npm run build` - Build for production
- `npm run typecheck` - Run TypeScript type checking
- `npm run format.fix` - Format code with Prettier

## Project Structure

```
verba-website/
├── client/                 # Frontend React application
│   ├── pages/             # Page components
│   ├── lib/               # Utility functions
│   ├── global.css         # Global styles and theme
│   └── App.tsx            # Main app component
├── public/                # Static assets
├── tailwind.config.ts     # TailwindCSS configuration
├── vite.config.ts         # Vite configuration
└── package.json           # Dependencies and scripts
```

## Design System

### Colors

- **Primary**: Verba Green (#00FF80)
- **Background**: Dark (#121212)
- **Text**: Light (#FAFAFA)
- **Accent**: Various green shades

### Typography

- **Font Family**: Helvetica, Arial, sans-serif
- **Weights**: Light, Regular, Medium, Bold
- **Responsive scaling** for different screen sizes

### Animations

- **Scroll-triggered** animations using Framer Motion
- **Hover effects** on interactive elements
- **Parallax scrolling** for immersive experience
- **Loading animations** and micro-interactions

## Customization

The design system is built with CSS custom properties and can be easily customized by modifying:

1. **Colors**: Update CSS variables in `client/global.css`
2. **Typography**: Modify font settings in `tailwind.config.ts`
3. **Animations**: Adjust Framer Motion configurations in components
4. **Layout**: Update container and spacing utilities

## Production Build

```bash
npm run build
```

The built files will be available in the `dist/` directory.

## Browser Support

- Chrome (latest)
- Firefox (latest)
- Safari (latest)
- Edge (latest)

## License

© 2025 VERBA. All rights reserved.

import { defineConfig } from "vite";
import path from "path";

export default defineConfig({
  build: {
    lib: {
      entry: path.resolve(__dirname, "server/node-build.ts"),
      formats: ["es"],
      fileName: "node-build",
    },
    outDir: "dist/server",
    emptyOutDir: false,
    rollupOptions: {
      external: ["express", "cors", "path", "url"],
    },
  },
  resolve: {
    alias: {
      "@shared": path.resolve(__dirname, "./shared"),
    },
  },
});

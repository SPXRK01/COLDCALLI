import { useEffect, useState } from "react";
import { motion, useScroll, useTransform } from "framer-motion";

export default function Index() {
  const [isLoaded, setIsLoaded] = useState(false);
  const { scrollYProgress } = useScroll();
  const backgroundY = useTransform(scrollYProgress, [0, 1], ["0%", "100%"]);
  const textY = useTransform(scrollYProgress, [0, 1], ["0%", "200%"]);

  useEffect(() => {
    setIsLoaded(true);
  }, []);

  return (
    <div className="min-h-screen bg-background text-foreground">
      {/* Navigation */}
      <motion.nav
        initial={{ y: -100, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ duration: 0.8, delay: 0.2 }}
        className="fixed top-0 left-0 right-0 z-50 bg-background/80 backdrop-blur-md border-b border-border"
      >
        <div className="container-custom">
          <div className="flex items-center justify-between h-16">
            <motion.div
              whileHover={{ scale: 1.05 }}
              className="text-2xl font-bold text-gradient"
            >
              VERBA
            </motion.div>
            <div className="hidden md:flex items-center space-x-8">
              <a
                href="#history"
                className="text-muted-foreground hover:text-verba-500 transition-colors"
              >
                History
              </a>
              <a
                href="#typography"
                className="text-muted-foreground hover:text-verba-500 transition-colors"
              >
                Typography
              </a>
              <a
                href="#colors"
                className="text-muted-foreground hover:text-verba-500 transition-colors"
              >
                Colors
              </a>
              <a
                href="#presentation"
                className="text-muted-foreground hover:text-verba-500 transition-colors"
              >
                Presentation
              </a>
              <a
                href="#contact"
                className="text-muted-foreground hover:text-verba-500 transition-colors"
              >
                Contact
              </a>
            </div>
            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              className="bg-verba-500 text-background px-6 py-2 rounded-lg font-medium hover:bg-verba-400 transition-colors"
            >
              Get Started
            </motion.button>
          </div>
        </div>
      </motion.nav>

      {/* Hero Section */}
      <section className="relative min-h-screen flex items-center justify-center overflow-hidden">
        <motion.div
          style={{ y: backgroundY }}
          className="absolute inset-0 bg-gradient-to-br from-dark via-dark-secondary to-dark-tertiary"
        />

        {/* Animated background elements */}
        <div className="absolute inset-0">
          {[...Array(6)].map((_, i) => (
            <motion.div
              key={i}
              className="absolute w-32 h-32 bg-verba-500/10 rounded-full blur-xl"
              style={{
                left: `${Math.random() * 100}%`,
                top: `${Math.random() * 100}%`,
              }}
              animate={{
                x: [0, 100, 0],
                y: [0, -100, 0],
                scale: [1, 1.2, 1],
              }}
              transition={{
                duration: 10 + i * 2,
                repeat: Infinity,
                ease: "easeInOut",
              }}
            />
          ))}
        </div>

        <motion.div
          style={{ y: textY }}
          className="relative z-10 text-center max-w-6xl mx-auto px-4"
        >
          <motion.h1
            initial={{ opacity: 0, y: 100 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 1, delay: 0.5 }}
            className="text-6xl md:text-8xl lg:text-9xl font-bold tracking-tight mb-8"
          >
            <span className="text-gradient">VERBA</span>
          </motion.h1>

          <motion.p
            initial={{ opacity: 0, y: 50 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.8 }}
            className="text-xl md:text-2xl text-muted-foreground mb-12 max-w-3xl mx-auto"
          >
            2025 Presentation Branding Design
          </motion.p>

          <motion.div
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.6, delay: 1.1 }}
            className="flex flex-col sm:flex-row items-center justify-center gap-6"
          >
            <motion.button
              whileHover={{
                scale: 1.05,
                boxShadow: "0 0 30px hsl(var(--verba-500) / 0.4)",
              }}
              whileTap={{ scale: 0.95 }}
              className="bg-verba-500 text-background px-8 py-4 rounded-xl font-semibold text-lg hover:bg-verba-400 transition-all duration-300 verba-glow"
            >
              View Project
            </motion.button>
            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              className="border border-verba-500 text-verba-500 px-8 py-4 rounded-xl font-semibold text-lg hover:bg-verba-500 hover:text-background transition-all duration-300"
            >
              Learn More
            </motion.button>
          </motion.div>
        </motion.div>

        {/* Scroll indicator */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 2 }}
          className="absolute bottom-8 left-1/2 transform -translate-x-1/2"
        >
          <motion.div
            animate={{ y: [0, 10, 0] }}
            transition={{ duration: 2, repeat: Infinity }}
            className="w-6 h-10 border-2 border-verba-500 rounded-full flex justify-center"
          >
            <motion.div
              animate={{ y: [0, 16, 0] }}
              transition={{ duration: 2, repeat: Infinity }}
              className="w-1 h-3 bg-verba-500 rounded-full mt-2"
            />
          </motion.div>
        </motion.div>
      </section>

      {/* History of the Project Section */}
      <section id="history" className="py-32 bg-dark-secondary">
        <div className="container-custom">
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
            className="text-center mb-20"
          >
            <h2 className="text-5xl md:text-6xl font-bold mb-6">
              HISTORY OF <span className="text-gradient">THE PROJECT</span>
            </h2>
            <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
              A comprehensive look at the evolution and development of the VERBA
              brand identity, showcasing our journey from concept to final
              execution.
            </p>
          </motion.div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
            <motion.div
              initial={{ opacity: 0, x: -50 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.8 }}
            >
              <h3 className="text-3xl font-bold mb-6">Project Genesis</h3>
              <p className="text-muted-foreground mb-6 leading-relaxed">
                VERBA began as a vision to create a revolutionary branding
                experience that would push the boundaries of modern design. Our
                team embarked on an extensive research phase, analyzing market
                trends and consumer behavior.
              </p>
              <p className="text-muted-foreground leading-relaxed">
                The project evolved through multiple iterations, each refining
                our approach and strengthening the core visual identity that
                defines VERBA today.
              </p>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, x: 50 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.8, delay: 0.2 }}
              className="relative"
            >
              <div className="bg-card p-8 rounded-2xl border border-border">
                <div className="grid grid-cols-2 gap-4 mb-6">
                  <div className="bg-verba-500/20 p-4 rounded-lg">
                    <div className="text-2xl font-bold text-verba-500">
                      2024
                    </div>
                    <div className="text-sm text-muted-foreground">
                      Research Phase
                    </div>
                  </div>
                  <div className="bg-verba-500/20 p-4 rounded-lg">
                    <div className="text-2xl font-bold text-verba-500">6M</div>
                    <div className="text-sm text-muted-foreground">
                      Development
                    </div>
                  </div>
                </div>
                <div className="h-32 bg-gradient-to-r from-verba-500/20 to-verba-600/20 rounded-lg flex items-center justify-center">
                  <div className="text-4xl font-bold text-gradient">VERBA</div>
                </div>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Typography Section */}
      <section id="typography" className="py-32 bg-background">
        <div className="container-custom">
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
            className="text-center mb-20"
          >
            <h2 className="text-5xl md:text-6xl font-bold mb-6">
              <span className="text-gradient">TYPOGRAPHY</span>
            </h2>
          </motion.div>

          <div className="space-y-16">
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
              className="text-center"
            >
              <div className="text-8xl md:text-9xl font-bold tracking-tight mb-4">
                SYNĒ
              </div>
              <div className="text-6xl md:text-7xl font-light tracking-wide">
                Helvetica
              </div>
            </motion.div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
              <motion.div
                initial={{ opacity: 0, x: -30 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6 }}
                className="bg-card p-8 rounded-2xl border border-border"
              >
                <h3 className="text-2xl font-bold mb-4 text-verba-500">
                  Primary Typeface
                </h3>
                <div className="space-y-3">
                  <div className="text-4xl font-bold">Helvetica Bold</div>
                  <div className="text-2xl font-medium">Helvetica Medium</div>
                  <div className="text-xl">Helvetica Regular</div>
                  <div className="text-lg font-light">Helvetica Light</div>
                </div>
              </motion.div>

              <motion.div
                initial={{ opacity: 0, x: 30 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6, delay: 0.2 }}
                className="bg-card p-8 rounded-2xl border border-border"
              >
                <h3 className="text-2xl font-bold mb-4 text-verba-500">
                  Usage Guidelines
                </h3>
                <ul className="space-y-3 text-muted-foreground">
                  <li>• Headlines: Helvetica Bold</li>
                  <li>• Subheadings: Helvetica Medium</li>
                  <li>• Body text: Helvetica Regular</li>
                  <li>• Captions: Helvetica Light</li>
                </ul>
              </motion.div>
            </div>
          </div>
        </div>
      </section>

      {/* Colors Section */}
      <section id="colors" className="py-32 bg-dark-secondary">
        <div className="container-custom">
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
            className="text-center mb-20"
          >
            <h2 className="text-5xl md:text-6xl font-bold mb-6">
              COLORS USED FOR <span className="text-gradient">THE PROJECT</span>
            </h2>
          </motion.div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
            <motion.div
              initial={{ opacity: 0, x: -50 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.8 }}
              className="space-y-8"
            >
              <div className="bg-card p-8 rounded-2xl border border-border">
                <h3 className="text-2xl font-bold mb-6 text-verba-500">
                  Primary Palette
                </h3>
                <div className="grid grid-cols-3 gap-4">
                  <div className="text-center">
                    <div className="w-full h-20 bg-verba-500 rounded-lg mb-2 verba-glow"></div>
                    <div className="text-sm font-medium">Verba Green</div>
                    <div className="text-xs text-muted-foreground">#00FF80</div>
                  </div>
                  <div className="text-center">
                    <div className="w-full h-20 bg-background rounded-lg mb-2 border border-border"></div>
                    <div className="text-sm font-medium">Dark Base</div>
                    <div className="text-xs text-muted-foreground">#121212</div>
                  </div>
                  <div className="text-center">
                    <div className="w-full h-20 bg-foreground rounded-lg mb-2"></div>
                    <div className="text-sm font-medium">Light Text</div>
                    <div className="text-xs text-muted-foreground">#FAFAFA</div>
                  </div>
                </div>
              </div>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, x: 50 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.8, delay: 0.2 }}
              className="relative"
            >
              <div className="w-full h-96 bg-gradient-to-br from-verba-500 via-verba-600 to-verba-700 rounded-2xl relative overflow-hidden">
                <div className="absolute inset-0 bg-black/20"></div>
                <div className="absolute inset-0 flex items-center justify-center">
                  <div className="text-6xl font-bold text-white opacity-80">
                    VERBA
                  </div>
                </div>
                <motion.div
                  animate={{ rotate: 360 }}
                  transition={{
                    duration: 20,
                    repeat: Infinity,
                    ease: "linear",
                  }}
                  className="absolute top-4 right-4 w-16 h-16 border-2 border-white/30 rounded-full"
                />
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Final Presentation Section */}
      <section id="presentation" className="py-32 bg-background">
        <div className="container-custom">
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
            className="text-center mb-20"
          >
            <h2 className="text-5xl md:text-6xl font-bold mb-6">
              FINAL <span className="text-gradient">PRESENTATION</span>
            </h2>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
            className="relative bg-card p-12 rounded-3xl border border-border overflow-hidden"
          >
            <div className="absolute inset-0 bg-gradient-to-br from-verba-500/5 to-verba-600/5"></div>
            <div className="relative z-10 text-center">
              <div className="text-8xl md:text-9xl font-bold text-gradient mb-8">
                VERBA
              </div>
              <p className="text-xl text-muted-foreground mb-12 max-w-2xl mx-auto">
                A complete brand identity system designed for the future of
                digital communication.
              </p>

              <div className="grid grid-cols-2 md:grid-cols-4 gap-8 mb-12">
                {[
                  { label: "Designs", value: "50+" },
                  { label: "Variants", value: "60+" },
                  { label: "Colors", value: "20+" },
                  { label: "Completion", value: "100%" },
                ].map((stat, index) => (
                  <motion.div
                    key={index}
                    initial={{ opacity: 0, y: 20 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    viewport={{ once: true }}
                    transition={{ duration: 0.5, delay: index * 0.1 }}
                    className="text-center"
                  >
                    <div className="text-3xl font-bold text-verba-500">
                      {stat.value}
                    </div>
                    <div className="text-sm text-muted-foreground">
                      {stat.label}
                    </div>
                  </motion.div>
                ))}
              </div>

              <motion.button
                whileHover={{
                  scale: 1.05,
                  boxShadow: "0 0 30px hsl(var(--verba-500) / 0.4)",
                }}
                whileTap={{ scale: 0.95 }}
                className="bg-verba-500 text-background px-12 py-4 rounded-xl font-semibold text-lg hover:bg-verba-400 transition-all duration-300 verba-glow"
              >
                Download Presentation
              </motion.button>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Contact Section */}
      <section id="contact" className="py-32 bg-dark-secondary">
        <div className="container-custom">
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
            className="text-center mb-20"
          >
            <h2 className="text-5xl md:text-6xl font-bold mb-6">
              CONTACT <span className="text-gradient">US</span>
            </h2>
            <p className="text-xl text-muted-foreground">
              Ready to start your project? Let's talk.
            </p>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
            className="max-w-4xl mx-auto"
          >
            <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
              <div className="space-y-8">
                <div>
                  <h3 className="text-2xl font-bold mb-4 text-verba-500">
                    Get in Touch
                  </h3>
                  <p className="text-muted-foreground">
                    We're here to help bring your vision to life. Reach out to
                    discuss your next project.
                  </p>
                </div>

                <div className="space-y-4">
                  <div className="flex items-center space-x-4">
                    <div className="w-12 h-12 bg-verba-500/20 rounded-lg flex items-center justify-center">
                      <div className="w-6 h-6 bg-verba-500 rounded"></div>
                    </div>
                    <div>
                      <div className="font-semibold">Email</div>
                      <div className="text-muted-foreground">
                        hello@verba.design
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center space-x-4">
                    <div className="w-12 h-12 bg-verba-500/20 rounded-lg flex items-center justify-center">
                      <div className="w-6 h-6 bg-verba-500 rounded"></div>
                    </div>
                    <div>
                      <div className="font-semibold">Phone</div>
                      <div className="text-muted-foreground">
                        +1 (555) 123-4567
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              <div className="bg-card p-8 rounded-2xl border border-border">
                <form className="space-y-6">
                  <div>
                    <label className="block text-sm font-medium mb-2">
                      Name
                    </label>
                    <input
                      type="text"
                      className="w-full px-4 py-3 bg-background border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-verba-500 transition-colors"
                      placeholder="Your name"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-2">
                      Email
                    </label>
                    <input
                      type="email"
                      className="w-full px-4 py-3 bg-background border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-verba-500 transition-colors"
                      placeholder="your@email.com"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-2">
                      Message
                    </label>
                    <textarea
                      rows={4}
                      className="w-full px-4 py-3 bg-background border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-verba-500 transition-colors resize-none"
                      placeholder="Tell us about your project..."
                    />
                  </div>
                  <motion.button
                    whileHover={{ scale: 1.02 }}
                    whileTap={{ scale: 0.98 }}
                    type="submit"
                    className="w-full bg-verba-500 text-background py-3 rounded-lg font-semibold hover:bg-verba-400 transition-colors"
                  >
                    Send Message
                  </motion.button>
                </form>
              </div>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-16 bg-background border-t border-border">
        <div className="container-custom">
          <div className="flex flex-col md:flex-row items-center justify-between">
            <motion.div
              whileHover={{ scale: 1.05 }}
              className="text-3xl font-bold text-gradient mb-4 md:mb-0"
            >
              VERBA
            </motion.div>

            <div className="flex items-center space-x-8">
              <a
                href="#"
                className="text-muted-foreground hover:text-verba-500 transition-colors"
              >
                Privacy
              </a>
              <a
                href="#"
                className="text-muted-foreground hover:text-verba-500 transition-colors"
              >
                Terms
              </a>
              <a
                href="#"
                className="text-muted-foreground hover:text-verba-500 transition-colors"
              >
                Support
              </a>
            </div>
          </div>

          <div className="mt-8 pt-8 border-t border-border text-center text-muted-foreground">
            <p>
              &copy; 2025 VERBA. All rights reserved. Designed for the future.
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}

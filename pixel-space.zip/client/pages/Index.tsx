import { useEffect, useState } from "react";
import { motion, useScroll, useTransform, useMotionValueEvent } from "framer-motion";

export default function Index() {
  const [isLoaded, setIsLoaded] = useState(false);
  const [currentTestimonial, setCurrentTestimonial] = useState(0);
  const [activeWorkflow, setActiveWorkflow] = useState(0);
  const [isNavVisible, setIsNavVisible] = useState(true);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [activeCategory, setActiveCategory] = useState(0);
  const [activeFAQ, setActiveFAQ] = useState(null);
  const { scrollYProgress, scrollY } = useScroll();
  const backgroundY = useTransform(scrollYProgress, [0, 1], ["0%", "50%"]);

  useMotionValueEvent(scrollY, "change", (latest) => {
    const previous = scrollY.getPrevious();
    if (latest > previous && latest > 150) {
      setIsNavVisible(false);
    } else {
      setIsNavVisible(true);
    }
  });

  useEffect(() => {
    setIsLoaded(true);
    // Auto-rotate testimonials
    const interval = setInterval(() => {
      setCurrentTestimonial((prev) => (prev + 1) % testimonials.length);
    }, 5000);
    return () => clearInterval(interval);
  }, []);

  const testimonials = [
    {
      quote:
        "SPXRK transformed our customer support with their AI chatbot. 40% reduction in response time.",
      author: "Sarah Johnson",
      role: "CTO at TechFlow",
      company: "TechFlow Solutions",
    },
    {
      quote:
        "The AI integration was seamless. Our users love the instant, intelligent responses.",
      author: "Michael Chen",
      role: "Product Manager",
      company: "InnovateLabs",
    },
    {
      quote:
        "Best investment we made this year. The AI chatbot handles 80% of our customer queries.",
      author: "Emma Rodriguez",
      role: "CEO",
      company: "StartupNext",
    },
  ];

  return (
    <div className="min-h-screen bg-black text-foreground overflow-x-hidden">
      {/* Navigation */}
      <motion.nav
        initial={{ y: -100, opacity: 0 }}
        animate={{
          y: isNavVisible ? 0 : -100,
          opacity: isNavVisible ? 1 : 0
        }}
        transition={{ duration: 0.3 }}
        className="fixed top-0 left-0 right-0 z-50 px-2 pt-2"
      >
        <div className="bg-black/95 backdrop-blur-md border border-gray-800/30 rounded-2xl shadow-lg">
          <div className="flex items-center justify-between h-12 px-6">
            {/* Logo */}
            <motion.div
              whileHover={{ scale: 1.05 }}
              className="flex items-center"
            >
              <div className="text-2xl font-bold text-white font-display">
                SPXRK
              </div>
            </motion.div>

            {/* Desktop Navigation Menu */}
            <div className="hidden lg:flex items-center space-x-10">
              <a
                href="#benefits"
                className="text-gray-300 hover:text-white transition-colors text-sm font-medium"
              >
                BENEFITS
              </a>
              <a
                href="#services"
                className="text-gray-300 hover:text-white transition-colors text-sm font-medium"
              >
                SERVICES
              </a>
              <a
                href="#how-we-work"
                className="text-gray-300 hover:text-white transition-colors text-sm font-medium"
              >
                HOW WE WORK
              </a>
              <a
                href="#projects"
                className="text-gray-300 hover:text-white transition-colors text-sm font-medium"
              >
                PROJECTS
              </a>
              <a
                href="#testimonials"
                className="text-gray-300 hover:text-white transition-colors text-sm font-medium"
              >
                TESTIMONIALS
              </a>
            </div>

            {/* Right Side - Desktop */}
            <div className="hidden lg:flex items-center space-x-6">
              <div className="hidden md:flex items-center space-x-4 text-xs text-gray-400">
                <div className="flex items-center space-x-2">
                  <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                  <span>2 SPOT AVAILABLE</span>
                </div>
              </div>
              <motion.button
                whileHover={{
                  scale: 1.05,
                  boxShadow: "0 0 30px rgba(147, 51, 234, 0.8), 0 0 60px rgba(147, 51, 234, 0.4), 0 0 100px rgba(59, 130, 246, 0.3)",
                }}
                whileTap={{ scale: 0.95 }}
                className="bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700 text-white px-6 py-2 rounded-lg font-medium transition-all duration-300 text-sm"
                style={{
                  boxShadow: '0 0 20px rgba(147, 51, 234, 0.6), 0 4px 15px rgba(0, 0, 0, 0.4)',
                  textShadow: '0 2px 4px rgba(0, 0, 0, 0.5)'
                }}
              >
                Lets Talk
              </motion.button>
            </div>

            {/* Mobile Menu - Right Side */}
            <div className="flex lg:hidden items-center space-x-4">
              {/* Mobile Hamburger Menu */}
              <motion.button
                whileTap={{ scale: 0.95 }}
                onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
                className="p-2 text-white hover:text-spxrk-400 transition-colors"
                aria-label="Toggle mobile menu"
              >
                <svg
                  className="w-6 h-6"
                  fill="none"
                  stroke="currentColor"
                  viewBox="0 0 24 24"
                >
                  {isMobileMenuOpen ? (
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={2}
                      d="M6 18L18 6M6 6l12 12"
                    />
                  ) : (
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={2}
                      d="M4 6h16M4 12h16M4 18h16"
                    />
                  )}
                </svg>
              </motion.button>

              <motion.button
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                className="bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700 text-white px-4 py-2 rounded-lg font-medium transition-all duration-300 text-sm"
              >
                Let's Talk
              </motion.button>
            </div>
          </div>
        </div>
      </motion.nav>

      {/* Mobile Navigation Drawer */}
      <motion.div
        initial={{ y: "-100%", opacity: 0 }}
        animate={{
          y: isMobileMenuOpen ? 0 : "-100%",
          opacity: isMobileMenuOpen ? 1 : 0
        }}
        transition={{
          type: "spring",
          stiffness: 300,
          damping: 30,
          duration: 0.5
        }}
        className="fixed top-2 right-2 h-[calc(100vh-1rem)] w-80 bg-black/95 backdrop-blur-md z-50 lg:hidden border border-gray-800/30 rounded-2xl shadow-lg"
      >
        <div className="flex flex-col h-full">
          {/* Mobile Menu Header */}
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{
              opacity: isMobileMenuOpen ? 1 : 0,
              y: isMobileMenuOpen ? 0 : -20
            }}
            transition={{ delay: 0.1, duration: 0.3 }}
            className="flex items-center justify-between p-6 border-b border-gray-700/50"
          >
            <div className="text-2xl font-bold text-white font-display">
              SPXRK
            </div>
            <motion.button
              whileTap={{ scale: 0.95 }}
              onClick={() => setIsMobileMenuOpen(false)}
              className="p-2 text-white hover:text-spxrk-400 transition-colors"
            >
              <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
              </svg>
            </motion.button>
          </motion.div>

          {/* Mobile Menu Items */}
          <div className="flex-1 px-6 py-8">
            <nav className="space-y-6">
              {[
                { name: "BENEFITS", href: "#benefits" },
                { name: "SERVICES", href: "#services" },
                { name: "HOW WE WORK", href: "#how-we-work" },
                { name: "ABOUT", href: "/about" },
                { name: "TESTIMONIALS", href: "#testimonials" },
              ].map((item, index) => (
                <motion.div
                  key={item.name}
                  initial={{ opacity: 0, y: -30 }}
                  animate={{
                    opacity: isMobileMenuOpen ? 1 : 0,
                    y: isMobileMenuOpen ? 0 : -30
                  }}
                  transition={{
                    delay: isMobileMenuOpen ? index * 0.1 : 0,
                    duration: 0.4,
                    ease: "easeOut"
                  }}
                  className="py-3 border-b border-gray-700/50"
                >
                  <a
                    href={item.href}
                    className="text-lg font-medium text-white hover:text-spxrk-400 transition-colors block"
                    onClick={() => setIsMobileMenuOpen(false)}
                  >
                    {item.name}
                  </a>
                </motion.div>
              ))}
            </nav>
          </div>
        </div>
      </motion.div>

      {/* Mobile Menu Overlay */}
      {isMobileMenuOpen && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 bg-black/50 z-40 lg:hidden"
          onClick={() => setIsMobileMenuOpen(false)}
        />
      )}

      {/* Hero Section */}
      <section className="relative min-h-screen flex items-center justify-center overflow-hidden bg-black">
        {/* Galactic Ring Background */}
        <div className="absolute inset-0">
          {/* Main Galactic Ring Image */}
          <div
            className="absolute inset-0 bg-cover bg-center bg-no-repeat"
            style={{
              backgroundImage: 'url(https://cdn.builder.io/api/v1/image/assets%2Fec919c34fbe14e8eb24a4592db8089d4%2Fdbb43b8b63fa48348fd1febff97a7562?format=webp&width=1920)',
              backgroundSize: 'contain',
              backgroundPosition: 'center right',
            }}
          />

          {/* Black gradient overlay for smooth blending */}
          <div className="absolute inset-0 bg-gradient-to-r from-black via-black/70 to-transparent" />
          <div className="absolute inset-0 bg-gradient-to-b from-black/50 via-transparent to-black/50" />

          {/* Purple and Blue Glow Effects around the ring */}
          <div className="absolute top-1/2 right-1/4 -translate-y-1/2 w-[600px] h-[600px] bg-gradient-radial from-purple-500/30 via-blue-500/20 to-transparent rounded-full blur-3xl animate-pulse" style={{ animationDuration: '4s' }} />
          <div className="absolute top-1/2 right-1/3 -translate-y-1/2 w-[400px] h-[400px] bg-gradient-radial from-blue-400/40 via-purple-400/30 to-transparent rounded-full blur-2xl animate-pulse" style={{ animationDuration: '6s', animationDelay: '1s' }} />
          <div className="absolute top-1/2 right-1/2 -translate-y-1/2 w-[800px] h-[800px] bg-gradient-radial from-purple-600/20 via-blue-600/15 to-transparent rounded-full blur-[100px] animate-pulse" style={{ animationDuration: '8s', animationDelay: '2s' }} />
        </div>


        <div className="relative z-10 text-center max-w-6xl mx-auto px-4">
          <motion.h1
            initial={{ opacity: 0, y: 100 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 1, delay: 0.5 }}
            className="text-3xl sm:text-4xl md:text-5xl lg:text-6xl xl:text-7xl font-bold tracking-tight mb-6 sm:mb-8 leading-tight font-display px-4"
            style={{
              color: '#FFFFFF',
              textShadow: '0 0 20px rgba(147, 51, 234, 0.8), 0 0 40px rgba(147, 51, 234, 0.4), 0 4px 8px rgba(0, 0, 0, 0.8)'
            }}
          >
            Flexible AI workflow automation{" "}
            <span
              className="block sm:inline"
              style={{
                background: 'linear-gradient(135deg, #A855F7 0%, #3B82F6 50%, #8B5CF6 100%)',
                WebkitBackgroundClip: 'text',
                WebkitTextFillColor: 'transparent',
                textShadow: '0 0 30px rgba(147, 51, 234, 0.9), 0 0 60px rgba(59, 130, 246, 0.6)'
              }}
            >
              for technical teams
            </span>
          </motion.h1>

          <motion.p
            initial={{ opacity: 0, y: 50 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.8 }}
            className="text-lg sm:text-xl md:text-2xl mb-8 sm:mb-12 max-w-4xl mx-auto leading-relaxed px-4"
            style={{
              color: '#FFFFFF',
              textShadow: '0 0 15px rgba(147, 51, 234, 0.6), 0 2px 4px rgba(0, 0, 0, 0.8)'
            }}
          >
            Build with the precision of code or the speed of drag-n-drop. Host with on-prem control or in-the-cloud convenience. SPXRK gives you more freedom to implement multi-step AI agents and integrate apps than any other tool.
          </motion.p>

          <motion.div
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.6, delay: 1.1 }}
            className="flex flex-col sm:flex-row items-center justify-center gap-4 sm:gap-6 px-4"
          >
            <motion.button
              whileHover={{
                scale: 1.05,
                boxShadow: "0 0 30px rgba(147, 51, 234, 0.8), 0 0 60px rgba(147, 51, 234, 0.4), 0 0 100px rgba(59, 130, 246, 0.3)",
              }}
              whileTap={{ scale: 0.95 }}
              className="w-full sm:w-auto bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700 text-white px-8 sm:px-12 py-3 sm:py-4 rounded-xl font-semibold text-base sm:text-lg transition-all duration-300"
              style={{
                boxShadow: '0 0 20px rgba(147, 51, 234, 0.6), 0 4px 15px rgba(0, 0, 0, 0.4)',
                textShadow: '0 2px 4px rgba(0, 0, 0, 0.5)'
              }}
            >
              Get started for free
            </motion.button>
            <motion.button
              whileHover={{
                scale: 1.05,
                boxShadow: "0 0 25px rgba(147, 51, 234, 0.6), 0 0 50px rgba(147, 51, 234, 0.3)"
              }}
              whileTap={{ scale: 0.95 }}
              className="w-full sm:w-auto border-2 border-purple-500/60 text-white hover:bg-purple-900/50 hover:border-purple-400 px-8 sm:px-12 py-3 sm:py-4 rounded-xl font-semibold text-base sm:text-lg transition-all duration-300"
              style={{
                backgroundColor: 'rgba(0, 0, 0, 0.4)',
                backdropFilter: 'blur(10px)',
                textShadow: '0 0 10px rgba(147, 51, 234, 0.8), 0 2px 4px rgba(0, 0, 0, 0.5)'
              }}
            >
              Talk to sales
            </motion.button>
          </motion.div>
        </div>


      </section>


      {/* About Section */}
      <section id="about" className="py-32 relative overflow-hidden">
        <div className="container-custom relative z-10">
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
            className="text-center mb-20"
          >
            <h2 className="text-5xl md:text-6xl font-bold mb-6 font-display">
              Who <span className="text-gradient">We Are</span>
            </h2>
            <p className="text-xl text-muted-foreground max-w-4xl mx-auto leading-relaxed">
              SPXRK is a top-tier AI agency focused on delivering intelligent
              automation solutions. We specialize in creating sophisticated AI
              chatbots and virtual assistants that transform how businesses
              interact with their customers.
            </p>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {[
              {
                title: "AI-First Approach",
                description:
                  "Built from the ground up with artificial intelligence at the core of every solution.",
              },
              {
                title: "Lightning Fast",
                description:
                  "Deploy intelligent chatbots in minutes, not weeks. Our platform is optimized for speed.",
              },
              {
                title: "Future-Ready",
                description:
                  "Stay ahead with cutting-edge AI technology that evolves with your business needs.",
              },
            ].map((item, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6, delay: index * 0.2 }}
                className="text-center group hover:scale-105 transition-all duration-300 relative overflow-hidden"
              >
                <div
                  className="h-full p-8 rounded-lg border border-gray-800/50 transition-all duration-300 group-hover:border-purple-500/30 group-hover:shadow-xl group-hover:shadow-purple-500/10"
                  style={{
                    background: 'linear-gradient(135deg, #000000 0%, #1a0a2e 50%, #2d1b69 100%)',
                    boxShadow: '0 4px 20px rgba(0, 0, 0, 0.3)'
                  }}
                >
                  <h3 className="text-2xl font-bold mb-4 text-white">
                    {item.title}
                  </h3>
                  <p className="text-gray-400 leading-relaxed">
                    {item.description}
                  </p>
                  {/* Subtle hover glow effect */}
                  <div className="absolute inset-0 rounded-lg bg-gradient-to-r from-purple-500/0 via-purple-500/5 to-purple-500/0 opacity-0 group-hover:opacity-100 transition-opacity duration-300 pointer-events-none" />
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Premium Services Section */}
      <section id="services" className="py-32 relative overflow-hidden">
        <div className="container-custom relative z-10">
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
            className="text-center mb-20"
          >
            <h2 className="text-5xl md:text-6xl font-bold mb-6 font-display">
              Our Core <span className="text-gradient">AI Services</span>
            </h2>
            <p className="text-xl text-muted-foreground max-w-4xl mx-auto leading-relaxed">
              Tailored automation solutions to accelerate your business growth
            </p>
          </motion.div>

          {/* Category Filter Tabs */}
          <div className="flex justify-center mb-16 px-4">
            {/* Desktop Layout */}
            <div className="hidden md:flex bg-gray-900/50 border border-gray-700 rounded-2xl p-2 space-x-2">
              {['Communication', 'Marketing', 'Custom AI'].map((category, index) => (
                <motion.button
                  key={category}
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                  onClick={() => setActiveCategory(index)}
                  className={`px-6 py-3 rounded-xl font-medium text-sm transition-all duration-200 ease-out ${
                    activeCategory === index
                      ? 'bg-[#7B2FFF] text-white shadow-lg'
                      : 'text-gray-400 hover:text-white hover:bg-gray-800/50'
                  }`}
                >
                  {category}
                </motion.button>
              ))}
            </div>

            {/* Mobile Layout - Horizontal Scroll */}
            <div className="md:hidden w-full max-w-sm">
              <div className="bg-gray-900/50 border border-gray-700 rounded-2xl p-2">
                <div className="flex space-x-4 overflow-x-auto scrollbar-hide px-2 py-1" style={{ scrollbarWidth: 'none', msOverflowStyle: 'none' }}>
                  {['Communication', 'Marketing', 'Custom AI'].map((category, index) => (
                    <motion.button
                      key={category}
                      whileHover={{ scale: 1.02 }}
                      whileTap={{ scale: 0.98 }}
                      onClick={() => setActiveCategory(index)}
                      className={`flex-shrink-0 px-6 py-3 h-11 rounded-xl font-medium text-sm whitespace-nowrap transition-all duration-200 ease-out ${
                        activeCategory === index
                          ? 'bg-[#7B2FFF] text-white shadow-lg'
                          : 'text-gray-400 hover:text-white hover:bg-gray-800/50'
                      }`}
                    >
                      {category}
                    </motion.button>
                  ))}
                </div>
              </div>
            </div>
          </div>

          {/* Service Cards Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {(() => {
              const services = [
                // Communication Services
                [
                  {
                    title: "AI Receptionist",
                    description: "Handles calls, books appointments, and manages inbound & outbound communication — 24/7 availability.",
                  },
                  {
                    title: "WhatsApp AI Chatbot",
                    description: "Smart automated replies and lead capture for your business via WhatsApp.",
                  },
                  {
                    title: "AI Chatbots for Websites & Apps",
                    description: "Conversational AI for instant customer support and engagement.",
                  }
                ],
                // Marketing Services
                [
                  {
                    title: "AI Marketing Media",
                    description: "Ads, product images, and fully edited videos to boost your brand.",
                  },
                  {
                    title: "Cold Emails + WhatsApp Drip AI",
                    description: "Automated outreach for lead generation.",
                  }
                ],
                // Custom AI Services
                [
                  {
                    title: "CRM Automation",
                    description: "Streamline client management with automated workflows.",
                  },
                  {
                    title: "Problem-to-Solution AI",
                    description: "Share your challenge, and we design a custom AI solution if eligible.",
                  }
                ]
              ];

              return services[activeCategory].map((service, index) => (
                <motion.div
                  key={`${activeCategory}-${index}`}
                  initial={{ opacity: 0, y: 30 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.6, delay: index * 0.1 }}
                  whileHover={{
                    y: -8,
                    transition: { duration: 0.3 }
                  }}
                  className="group transition-all duration-300 relative overflow-hidden"
                >
                  <div
                    className="h-full p-8 rounded-lg border border-gray-800/50 transition-all duration-300 group-hover:border-purple-500/30 group-hover:shadow-xl group-hover:shadow-purple-500/10"
                    style={{
                      background: 'linear-gradient(135deg, #000000 0%, #1a0a2e 50%, #2d1b69 100%)',
                      boxShadow: '0 4px 20px rgba(0, 0, 0, 0.3)'
                    }}
                  >
                    {/* Service Title */}
                    <h4 className="text-xl font-bold mb-4 text-white group-hover:text-spxrk-400 transition-colors duration-300 font-display">
                      {service.title}
                    </h4>

                    {/* Service Description */}
                    <p className="text-gray-400 leading-relaxed mb-8 min-h-[60px]">
                      {service.description}
                    </p>

                    {/* Get Quote Button */}
                    <motion.button
                      whileHover={{
                        scale: 1.05,
                        boxShadow: "0 0 30px rgba(138, 43, 226, 0.4), 0 0 60px rgba(108, 0, 255, 0.2)"
                      }}
                      whileTap={{ scale: 0.97 }}
                      onClick={() => {
                        const contactSection = document.getElementById('contact') ||
                                             document.querySelector('[id*="contact"]') ||
                                             document.querySelector('[id*="booking"]') ||
                                             document.querySelector('footer');
                        if (contactSection) {
                          contactSection.scrollIntoView({ behavior: 'smooth' });
                        }
                      }}
                      className="w-full bg-gradient-to-r from-spxrk-500 to-neon-purple hover:from-neon-purple hover:to-spxrk-600 text-white px-6 py-4 rounded-2xl font-bold text-base transition-all duration-300 ease-out spxrk-glow shadow-lg hover:shadow-spxrk-500/25"
                      style={{
                        background: 'linear-gradient(135deg, #8A2BE2 0%, #6C00FF 100%)',
                      }}
                    >
                      Get Quote
                    </motion.button>
                    {/* Subtle hover glow effect */}
                    <div className="absolute inset-0 rounded-lg bg-gradient-to-r from-purple-500/0 via-purple-500/5 to-purple-500/0 opacity-0 group-hover:opacity-100 transition-opacity duration-300 pointer-events-none" />
                  </div>
                </motion.div>
              ));
            })()}
          </div>

          {/* Background Animated Particles */}
          <div className="absolute top-1/2 left-1/4 w-96 h-96 bg-gradient-to-r from-spxrk-500/8 to-neon-purple/8 rounded-full blur-3xl opacity-60 animate-pulse pointer-events-none"></div>
          <div className="absolute bottom-1/4 right-1/4 w-64 h-64 bg-gradient-to-l from-neon-purple/8 to-spxrk-500/8 rounded-full blur-2xl opacity-40 animate-pulse pointer-events-none" style={{ animationDelay: '2s' }}></div>

          {/* Additional floating particles */}
          {[...Array(6)].map((_, i) => (
            <motion.div
              key={i}
              animate={{
                y: [0, -20, 0],
                opacity: [0.2, 0.5, 0.2],
              }}
              transition={{
                duration: 4 + i,
                repeat: Infinity,
                ease: "easeInOut",
                delay: i * 0.8,
              }}
              className="absolute w-2 h-2 bg-spxrk-500/30 rounded-full blur-sm pointer-events-none"
              style={{
                left: `${15 + i * 12}%`,
                top: `${25 + (i % 3) * 20}%`,
              }}
            />
          ))}
        </div>
      </section>

      {/* How SPXRK.AI Works Section */}
      <section id="how-we-work" className="py-32 relative overflow-hidden">
        <div className="container-custom relative z-10">
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
            className="text-center mb-20"
          >
            <h2 className="text-4xl md:text-5xl lg:text-6xl font-bold mb-4 font-display text-white">
              Here's How <span className="text-gradient">SPXRK.AI</span> Works:
            </h2>
            <p className="text-lg md:text-xl text-gray-400 max-w-2xl mx-auto">
              Transform your business in three simple steps
            </p>
          </motion.div>

          {/* Three Steps Grid */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 md:gap-12">
            {[
              {
                step: "STEP 1",
                icon: "📅",
                title: "Book a Free Discovery Call",
                description: "Schedule a consultation to discuss your business needs and goals with our AI experts."
              },
              {
                step: "STEP 2",
                icon: "💡",
                title: "Get Your Custom AI Plan",
                description: "Receive tailored recommendations for implementing AI solutions across your business."
              },
              {
                step: "STEP 3",
                icon: "📈",
                title: "Watch Your Business Scale",
                description: "Experience transformative results as our AI-powered tools optimize your operations."
              }
            ].map((item, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6, delay: index * 0.2 }}
                className="text-center group"
              >
                {/* Step Label */}
                <div className="text-sm font-medium text-spxrk-400 mb-4 tracking-wider">
                  {item.step}
                </div>

                {/* Icon Container */}
                <motion.div
                  whileHover={{ scale: 1.1, rotate: 5 }}
                  transition={{ duration: 0.3 }}
                  className="w-20 h-20 mx-auto mb-6 bg-gradient-to-br from-spxrk-500/20 to-neon-purple/20 rounded-2xl border border-spxrk-500/30 flex items-center justify-center text-4xl group-hover:border-spxrk-500/60 group-hover:shadow-lg group-hover:shadow-spxrk-500/25 transition-all duration-300"
                >
                  {item.icon}
                </motion.div>

                {/* Title */}
                <h3 className="text-xl md:text-2xl font-bold text-white mb-4 font-display group-hover:text-spxrk-400 transition-colors duration-300">
                  {item.title}
                </h3>

                {/* Description */}
                <p className="text-gray-400 leading-relaxed max-w-sm mx-auto">
                  {item.description}
                </p>
              </motion.div>
            ))}
          </div>

          {/* Background Decorative Elements */}
          <div className="absolute top-1/4 left-1/6 w-32 h-32 bg-gradient-to-r from-spxrk-500/10 to-neon-purple/10 rounded-full blur-2xl opacity-60 animate-pulse pointer-events-none"></div>
          <div className="absolute bottom-1/4 right-1/6 w-24 h-24 bg-gradient-to-l from-neon-purple/10 to-spxrk-500/10 rounded-full blur-xl opacity-40 animate-pulse pointer-events-none" style={{ animationDelay: '1s' }}></div>
        </div>
      </section>

      {/* About SPXRK.AI Section */}
      <section id="features" className="py-32 relative overflow-hidden">
        <div className="container-custom relative z-10">
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
            className="text-center mb-20"
          >
            <h2 className="text-5xl md:text-6xl font-bold mb-6 font-display">
              About <span className="text-gradient">SPXRK.AI</span>
            </h2>
            <p className="text-xl text-muted-foreground max-w-4xl mx-auto leading-relaxed">
              We're revolutionizing business automation through cutting-edge AI solutions. Our mission is to empower organizations with intelligent systems that drive efficiency and growth.
            </p>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {[
              {
                title: "Advanced AI",
                description: "State-of-the-art artificial intelligence powering your business processes",
                icon: "🔧"
              },
              {
                title: "Seamless Integration",
                description: "Effortlessly integrate our solutions with your existing infrastructure",
                icon: "🔗"
              },
              {
                title: "Rapid Deployment",
                description: "Quick implementation and deployment of AI solutions",
                icon: "��"
              },
              {
                title: "24/7 Support",
                description: "Round-the-clock monitoring and support for your AI systems",
                icon: "🛡️"
              },
            ].map((feature, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
                className="group transition-all duration-300 hover:scale-105 relative overflow-hidden"
              >
                <div
                  className="h-full p-8 rounded-lg border border-gray-800/50 transition-all duration-300 group-hover:border-purple-500/30 group-hover:shadow-xl group-hover:shadow-purple-500/10"
                  style={{
                    background: 'linear-gradient(135deg, #000000 0%, #1a0a2e 50%, #2d1b69 100%)',
                    boxShadow: '0 4px 20px rgba(0, 0, 0, 0.3)'
                  }}
                >
                  {/* Icon */}
                  <motion.div
                    whileHover={{ scale: 1.1, rotate: 5 }}
                    transition={{ duration: 0.3 }}
                    className="w-16 h-16 mx-auto mb-6 bg-gradient-to-br from-spxrk-500/20 to-neon-purple/20 rounded-2xl border border-spxrk-500/30 flex items-center justify-center text-2xl group-hover:border-spxrk-500/60 group-hover:shadow-lg group-hover:shadow-spxrk-500/25 transition-all duration-300"
                  >
                    {feature.icon}
                  </motion.div>

                  <h3 className="text-xl font-bold mb-4 text-white group-hover:text-spxrk-400 transition-colors duration-300">
                    {feature.title}
                  </h3>
                  <p className="text-gray-400 leading-relaxed">
                    {feature.description}
                  </p>
                  {/* Subtle hover glow effect */}
                  <div className="absolute inset-0 rounded-lg bg-gradient-to-r from-purple-500/0 via-purple-500/5 to-purple-500/0 opacity-0 group-hover:opacity-100 transition-opacity duration-300 pointer-events-none" />
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>


      {/* Key Benefits Section */}
      <section className="py-32 relative overflow-hidden">
        <div className="container-custom relative z-10">
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
            className="text-center mb-20"
          >
            <h2 className="text-5xl md:text-6xl font-bold mb-6 font-display text-white">
              The Key Benefits of AI
            </h2>
            <h3 className="text-4xl md:text-5xl font-bold mb-8 text-gradient font-display">
              for Your Business Growth
            </h3>
            <p className="text-xl text-muted-foreground max-w-4xl mx-auto leading-relaxed">
              Discover how AI automation enhances efficiency, reduces costs, and drives business growth with smarter, faster processes.
            </p>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[
              {
                title: "Increased Productivity",
                description: "Gain actionable insights with AI-driven analytics to improve decision-making and strategy.",
                icon: (
                  <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
                  </svg>
                )
              },
              {
                title: "Better Customer Experience",
                description: "Personalized AI interactions improve response times, customer engagement, and overall satisfaction.",
                icon: (
                  <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" />
                  </svg>
                )
              },
              {
                title: "24/7 Availability",
                description: "AI-powered systems operate around the clock, ensuring seamless support and execution without downtime.",
                icon: (
                  <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
                  </svg>
                )
              },
              {
                title: "Cost Reduction",
                description: "AI automation minimizes manual work, cuts operational costs, and optimizes resource allocation for better profitability.",
                icon: (
                  <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1" />
                  </svg>
                )
              },
              {
                title: "Data-Driven Insights",
                description: "Leverage AI to analyze vast data sets, identify trends, and make smarter, faster, and more accurate business decisions.",
                icon: (
                  <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" />
                  </svg>
                )
              },
              {
                title: "Scalability & Growth",
                description: "AI adapts to your business needs, allowing you to scale efficiently without increasing workload or costs.",
                icon: (
                  <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M7 11l5-5m0 0l5 5m-5-5v12" />
                  </svg>
                )
              },
            ].map((benefit, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
                className="group relative overflow-hidden"
              >
                {/* Modern SaaS-style Feature Box */}
                <div
                  className="h-full p-8 rounded-lg border border-gray-800/50 transition-all duration-300 group-hover:scale-[1.02] group-hover:border-purple-500/30 group-hover:shadow-xl group-hover:shadow-purple-500/10"
                  style={{
                    background: 'linear-gradient(135deg, #000000 0%, #1a0a2e 50%, #2d1b69 100%)',
                    boxShadow: '0 4px 20px rgba(0, 0, 0, 0.3)'
                  }}
                >
                  {/* Icon - Top Left */}
                  <div className="flex items-center justify-center w-12 h-12 mb-6 rounded-lg bg-gradient-to-r from-white to-purple-200 text-black group-hover:from-purple-400 group-hover:to-purple-600 group-hover:text-white transition-all duration-300">
                    {benefit.icon}
                  </div>

                  {/* Bold Heading */}
                  <h3 className="text-xl font-bold mb-4 text-white group-hover:text-purple-300 transition-colors duration-300">
                    {benefit.title}
                  </h3>

                  {/* Description */}
                  <p className="text-gray-400 leading-relaxed text-sm group-hover:text-gray-300 transition-colors duration-300">
                    {benefit.description}
                  </p>

                  {/* Subtle hover glow effect */}
                  <div className="absolute inset-0 rounded-lg bg-gradient-to-r from-purple-500/0 via-purple-500/5 to-purple-500/0 opacity-0 group-hover:opacity-100 transition-opacity duration-300 pointer-events-none" />
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Pricing Section */}
      <section className="py-32 relative overflow-hidden bg-black">
        <div className="container-custom relative z-10">
          {/* Header Section */}
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
            className="text-center mb-16"
          >
            {/* Pricing Badge */}
            <div className="inline-block bg-purple-500/20 border border-purple-500/30 rounded-full px-4 py-2 mb-8">
              <span className="text-purple-400 font-medium text-sm">Pricing</span>
            </div>

            {/* Title */}
            <h2 className="text-4xl md:text-5xl lg:text-6xl font-bold mb-4 text-white">
              The Best AI Automation,
            </h2>
            <h3 className="text-4xl md:text-5xl lg:text-6xl font-bold mb-8 text-white">
              at the Right Price
            </h3>

            {/* Subtitle */}
            <p className="text-lg text-gray-400 max-w-2xl mx-auto mb-12">
              Choose a plan that fits your business needs and start automating with AI
            </p>

            {/* Monthly/Annual Toggle */}
            <div className="flex items-center justify-center space-x-4 mb-16">
              <span className="text-gray-400 font-medium">Monthly</span>
              <div className="relative">
                <div className="w-16 h-8 bg-purple-600 rounded-full flex items-center justify-end px-1 transition-all duration-300">
                  <div className="w-6 h-6 bg-white rounded-full shadow-md"></div>
                </div>
              </div>
              <span className="text-white font-medium">Annually</span>
            </div>
          </motion.div>

          {/* Pricing Cards */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 max-w-7xl mx-auto">
            {[
              {
                name: "Starter",
                price: "$37",
                period: "/month",
                description: "Perfect for small businesses starting with AI automation.",
                icon: "🚀",
                features: [
                  "Basic workflow automation",
                  "AI-powered personal assistant",
                  "Standard analytics & reporting",
                  "Email & chat support",
                  "Up to 3 AI integrations"
                ],
                buttonText: "Choose this plan",
                buttonStyle: "bg-gray-800 hover:bg-gray-700 text-white",
                popular: false
              },
              {
                name: "Professional",
                price: "$75",
                period: "/month",
                description: "Perfect for small businesses starting with AI automation.",
                icon: "⚡",
                features: [
                  "Advanced workflow automation",
                  "AI-driven sales & marketing tools",
                  "Enhanced data analytics & insights",
                  "Priority customer support",
                  "Up to 10 AI integrations"
                ],
                buttonText: "Choose this plan",
                buttonStyle: "bg-gradient-to-r from-purple-600 to-purple-700 hover:from-purple-700 hover:to-purple-800 text-white shadow-lg shadow-purple-500/25",
                popular: true
              },
              {
                name: "Enterprise",
                price: "Custom",
                period: "",
                description: "Perfect for small businesses starting with AI automation.",
                icon: "👑",
                features: [
                  "Fully customizable AI automation",
                  "Dedicated AI business consultant",
                  "Enterprise-grade compliance",
                  "24/7 VIP support",
                  "Unlimited AI integrations"
                ],
                buttonText: "Schedule a call",
                buttonStyle: "bg-gray-800 hover:bg-gray-700 text-white",
                popular: false
              }
            ].map((plan, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
                className="relative group"
              >
                {/* Popular Label */}
                {plan.popular && (
                  <div className="absolute top-4 right-4 z-10">
                    <span className="bg-purple-600 text-white px-3 py-1 rounded text-sm font-medium">
                      Popular
                    </span>
                  </div>
                )}

                {/* Card */}
                <div
                  className="h-full p-8 border border-gray-800/50 transition-all duration-300 group-hover:scale-[1.02] group-hover:border-purple-500/30 group-hover:shadow-xl group-hover:shadow-purple-500/10"
                  style={{
                    background: 'linear-gradient(135deg, #000000 0%, #1a0a2e 50%, #2d1b69 100%)',
                    boxShadow: '0 4px 20px rgba(0, 0, 0, 0.3)',
                    borderRadius: '8px'
                  }}
                >
                  {/* Subtle hover glow effect */}
                  <div className="absolute inset-0 rounded-lg bg-gradient-to-r from-purple-500/0 via-purple-500/5 to-purple-500/0 opacity-0 group-hover:opacity-100 transition-opacity duration-300 pointer-events-none" />

                  {/* Plan Header */}
                  <div className="flex items-center mb-6">
                    <span className="text-2xl mr-3">{plan.icon}</span>
                    <h3 className="text-xl font-bold text-white">{plan.name}</h3>
                  </div>

                  {/* Price */}
                  <div className="mb-6">
                    <div className="flex items-baseline mb-2">
                      <span className="text-4xl font-bold text-white">{plan.price}</span>
                      <span className="text-gray-400 ml-1">{plan.period}</span>
                    </div>
                    <p className="text-gray-400 text-sm">{plan.description}</p>
                  </div>

                  {/* CTA Button */}
                  <motion.button
                    whileHover={{ scale: 1.02 }}
                    whileTap={{ scale: 0.98 }}
                    className={`w-full py-3 rounded-lg font-semibold text-sm transition-all duration-300 mb-8 ${plan.buttonStyle}`}
                  >
                    {plan.buttonText}
                  </motion.button>

                  {/* Features List */}
                  <div>
                    <h4 className="text-white font-semibold mb-4 text-sm">What's included:</h4>
                    <ul className="space-y-3">
                      {plan.features.map((feature, featureIndex) => (
                        <li key={featureIndex} className="flex items-start text-gray-300">
                          <svg className="w-5 h-5 text-green-500 mr-3 mt-0.5 flex-shrink-0" fill="currentColor" viewBox="0 0 20 20">
                            <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                          </svg>
                          <span className="text-sm leading-relaxed">{feature}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Testimonials Section */}
      <section
        id="testimonials"
        className="py-32 relative overflow-hidden"
      >
        <div className="absolute inset-0">
          <motion.div
            animate={{
              rotate: [0, 360],
              scale: [1, 1.1, 1],
            }}
            transition={{
              duration: 30,
              repeat: Infinity,
              ease: "linear",
            }}
            className="absolute top-0 right-0 w-[600px] h-[600px] opacity-10"
          >
            <div className="w-full h-full bg-gradient-to-br from-spxrk-500/20 to-neon-purple/10 rounded-full blur-3xl" />
          </motion.div>
        </div>

        <div className="container-custom relative z-10">
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
            className="text-center mb-20"
          >
            <h2 className="text-5xl md:text-6xl font-bold mb-6 font-display">
              What Our <span className="text-gradient">Clients Say</span>
            </h2>
          </motion.div>

          <div className="max-w-4xl mx-auto">
            <div className="relative h-96 overflow-hidden">
              {testimonials.map((testimonial, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, x: 100 }}
                  animate={{
                    opacity: index === currentTestimonial ? 1 : 0,
                    x: index === currentTestimonial ? 0 : 100,
                  }}
                  transition={{ duration: 0.5 }}
                  className={`absolute inset-0 ${index === currentTestimonial ? "block" : "hidden"}`}
                >
                  <div className="luxury-card p-12 rounded-3xl text-center">
                    <blockquote className="text-2xl md:text-3xl font-medium mb-8 text-gray-200 leading-relaxed">
                      "{testimonial.quote}"
                    </blockquote>
                    <div>
                      <div className="text-xl font-bold text-spxrk-400 mb-1">
                        {testimonial.author}
                      </div>
                      <div className="text-muted-foreground">
                        {testimonial.role}
                      </div>
                      <div className="text-sm text-spxrk-500 mt-1">
                        {testimonial.company}
                      </div>
                    </div>
                  </div>
                </motion.div>
              ))}
            </div>

            {/* Testimonial dots */}
            <div className="flex justify-center space-x-3 mt-8">
              {testimonials.map((_, index) => (
                <button
                  key={index}
                  onClick={() => setCurrentTestimonial(index)}
                  className={`w-3 h-3 rounded-full transition-all duration-300 ${
                    index === currentTestimonial
                      ? "bg-spxrk-500 w-8"
                      : "bg-gray-600"
                  }`}
                />
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <section className="py-32 relative overflow-hidden bg-black">
        <div className="container-custom relative z-10">
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
            className="text-center mb-20"
          >
            <div className="inline-block bg-gray-800/60 border border-gray-700/50 rounded-full px-6 py-2 mb-8">
              <span className="text-white font-medium text-sm tracking-wider uppercase">FAQs</span>
            </div>
            <h2 className="text-4xl md:text-5xl lg:text-6xl font-bold mb-2 font-display text-white">
              We've Got the Answers
            </h2>
            <h3 className="text-4xl md:text-5xl lg:text-6xl font-bold mb-8 font-display text-white">
              You're Looking For
            </h3>
            <p className="text-lg text-gray-400 max-w-2xl mx-auto">
              Quick answers to your AI automation questions.
            </p>
          </motion.div>

          <div className="max-w-4xl mx-auto">
            {[
              {
                question: "How can AI automation help my business?",
                answer: "AI automation eliminates repetitive tasks, improves efficiency, and reduces errors. It allows your team to focus on high-value work while increasing productivity and lowering operational costs."
              },
              {
                question: "Is AI automation difficult to integrate?",
                answer: "No! Our AI solutions are designed for seamless integration with your existing tools and workflows. We provide step-by-step guidance to ensure a smooth and hassle-free setup."
              },
              {
                question: "What industries can benefit from AI automation?",
                answer: "AI automation is beneficial across various industries, including marketing, sales, finance, healthcare, customer support, and operations. Any business looking to improve efficiency can leverage AI."
              },
              {
                question: "Do I need technical knowledge to use AI automation?",
                answer: "Not at all! Our platform is user-friendly and built for all skill levels. We provide onboarding, tutorials, and customer support to ensure you can easily navigate and use the system."
              },
              {
                question: "What kind of support do you offer?",
                answer: "We offer comprehensive support, including onboarding assistance, troubleshooting, and ongoing updates. Our team is available to help with any questions or technical issues you may have."
              }
            ].map((faq, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
                className="mb-4"
              >
                <motion.button
                  onClick={() => setActiveFAQ(activeFAQ === index ? null : index)}
                  className="w-full text-left bg-gray-900/80 border border-gray-700/60 rounded-xl p-6 hover:bg-gray-800/80 hover:border-gray-600/60 transition-all duration-300 group"
                  whileHover={{ scale: 1.005 }}
                  whileTap={{ scale: 0.995 }}
                >
                  <div className="flex items-center justify-between">
                    <h3 className="text-xl font-semibold text-white pr-4 group-hover:text-gray-100 transition-colors duration-300">
                      {faq.question}
                    </h3>
                    <motion.div
                      animate={{ rotate: activeFAQ === index ? 180 : 0 }}
                      transition={{ duration: 0.3 }}
                      className="flex-shrink-0"
                    >
                      <svg
                        className="w-5 h-5 text-gray-300"
                        fill="none"
                        stroke="currentColor"
                        viewBox="0 0 24 24"
                      >
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                      </svg>
                    </motion.div>
                  </div>
                </motion.button>

                <motion.div
                  initial={false}
                  animate={{
                    height: activeFAQ === index ? "auto" : 0,
                    opacity: activeFAQ === index ? 1 : 0
                  }}
                  transition={{ duration: 0.4, ease: "easeInOut" }}
                  className="overflow-hidden"
                >
                  <div className="bg-gray-800/60 border border-gray-700/40 rounded-xl mt-2 p-6">
                    <p className="text-gray-200 leading-relaxed text-lg font-normal">
                      {faq.answer}
                    </p>
                  </div>
                </motion.div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Call to Action Section */}
      <section className="py-32 bg-black relative overflow-hidden">
        <div className="container-custom relative z-10">
          <motion.div
            initial={{ opacity: 0, y: 50, scale: 0.95 }}
            whileInView={{ opacity: 1, y: 0, scale: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8, ease: "easeOut" }}
            className="max-w-4xl mx-auto"
          >
            <div
              className="relative overflow-hidden rounded-3xl p-12 md:p-16 text-center group hover:scale-[1.02] transition-all duration-500"
              style={{
                background: 'linear-gradient(135deg, #000000 0%, #1a0a2e 50%, #2d1b69 100%)',
                boxShadow: '0 8px 32px rgba(0, 0, 0, 0.4), 0 0 60px rgba(147, 51, 234, 0.2)'
              }}
            >
              {/* Background Effects */}
              <div className="absolute inset-0 rounded-3xl">
                <div className="absolute top-0 right-0 w-96 h-96 bg-gradient-radial from-purple-500/30 via-blue-500/20 to-transparent rounded-full blur-3xl opacity-60" />
                <div className="absolute bottom-0 left-0 w-80 h-80 bg-gradient-radial from-blue-400/20 via-purple-400/15 to-transparent rounded-full blur-2xl opacity-40" />
              </div>

              {/* Content */}
              <div className="relative z-10">
                <motion.h2
                  initial={{ opacity: 0, y: 30 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.6, delay: 0.2 }}
                  className="text-4xl md:text-5xl lg:text-6xl font-bold mb-6 font-display text-white leading-tight"
                >
                  Let AI do the Work so
                  <br />
                  <span className="text-white">you can Scale Faster</span>
                </motion.h2>

                <motion.p
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.6, delay: 0.4 }}
                  className="text-xl text-gray-300 mb-12 max-w-2xl mx-auto leading-relaxed"
                >
                  Book a Call Today and Start Automating
                </motion.p>

                <motion.button
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.6, delay: 0.6 }}
                  whileHover={{
                    scale: 1.05,
                    boxShadow: "0 0 30px rgba(147, 51, 234, 0.8), 0 0 60px rgba(147, 51, 234, 0.4), 0 0 100px rgba(59, 130, 246, 0.3)",
                  }}
                  whileTap={{ scale: 0.95 }}
                  className="bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700 text-white px-12 py-4 rounded-xl font-semibold text-lg transition-all duration-300 shadow-lg"
                  style={{
                    boxShadow: '0 0 20px rgba(147, 51, 234, 0.6), 0 4px 15px rgba(0, 0, 0, 0.4)',
                    textShadow: '0 2px 4px rgba(0, 0, 0, 0.5)'
                  }}
                >
                  Book a free call →
                </motion.button>
              </div>

              {/* Hover glow effect */}
              <div className="absolute inset-0 rounded-3xl bg-gradient-to-r from-purple-500/0 via-purple-500/5 to-purple-500/0 opacity-0 group-hover:opacity-100 transition-opacity duration-500 pointer-events-none" />
            </div>
          </motion.div>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-16 relative border-t border-gray-700/30">
        <div className="container-custom">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-12">
            <div className="col-span-1 md:col-span-2">
              <motion.div
                whileHover={{ scale: 1.05 }}
                className="text-4xl font-bold text-gradient mb-4 font-display"
              >
                SPXRK
              </motion.div>
              <p className="text-muted-foreground mb-6 max-w-md leading-relaxed">
                automate.scale.dominate
              </p>
              <div className="flex space-x-4">
                {[
                  {
                    name: "Instagram",
                    icon: "M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zm0-2.163c-3.259 0-3.667.014-4.947.072-4.358.2-6.78 2.618-6.98 6.98-.059 1.281-.073 1.689-.073 4.948 0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98 1.281.058 1.689.072 4.948.072 3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98-1.281-.059-1.69-.073-4.949-.073zm0 5.838c-3.403 0-6.162 2.759-6.162 6.162s2.759 6.163 6.162 6.163 6.162-2.759 6.162-6.163c0-3.403-2.759-6.162-6.162-6.162zm0 10.162c-2.209 0-4-1.79-4-4 0-2.209 1.791-4 4-4s4 1.791 4 4c0 2.21-1.791 4-4 4zm6.406-11.845c-.796 0-1.441.645-1.441 1.44s.645 1.44 1.441 1.44c.795 0 1.439-.645 1.439-1.44s-.644-1.44-1.439-1.44z",
                    url: "#",
                    hoverColor: "hover:text-pink-400"
                  },
                  {
                    name: "LinkedIn",
                    icon: "M20.447 20.452h-3.554v-5.569c0-1.328-.027-3.037-1.852-3.037-1.853 0-2.136 1.445-2.136 2.939v5.667H9.351V9h3.414v1.561h.046c.477-.9 1.637-1.85 3.37-1.85 3.601 0 4.267 2.37 4.267 5.455v6.286zM5.337 7.433c-1.144 0-2.063-.926-2.063-2.065 0-1.138.92-2.063 2.063-2.063 1.14 0 2.064.925 2.064 2.063 0 1.139-.925 2.065-2.064 2.065zm1.782 13.019H3.555V9h3.564v11.452zM22.225 0H1.771C.792 0 0 .774 0 1.729v20.542C0 23.227.792 24 1.771 24h20.451C23.2 24 24 23.227 24 22.271V1.729C24 .774 23.2 0 22.222 0h.003z",
                    url: "#",
                    hoverColor: "hover:text-blue-400"
                  },
                  {
                    name: "X",
                    icon: "M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z",
                    url: "#",
                    hoverColor: "hover:text-gray-300"
                  },
                  {
                    name: "GitHub",
                    icon: "M12 0c-6.626 0-12 5.373-12 12 0 5.302 3.438 9.8 8.207 11.387.599.111.793-.261.793-.577v-2.234c-3.338.726-4.033-1.416-4.033-1.416-.546-1.387-1.333-1.756-1.333-1.756-1.089-.745.083-.729.083-.729 1.205.084 1.839 1.237 1.839 1.237 1.07 1.834 2.807 1.304 3.492.997.107-.775.418-1.305.762-1.604-2.665-.305-5.467-1.334-5.467-5.931 0-1.311.469-2.381 1.236-3.221-.124-.303-.535-1.524.117-3.176 0 0 1.008-.322 3.301 1.23.957-.266 1.983-.399 3.003-.404 1.02.005 2.047.138 3.006.404 2.291-1.552 3.297-1.23 3.297-1.23.653 1.653.242 2.874.118 3.176.77.84 1.235 1.911 1.235 3.221 0 4.609-2.807 5.624-5.479 5.921.43.372.823 1.102.823 2.222v3.293c0 .319.192.694.801.576 4.765-1.589 8.199-6.086 8.199-11.386 0-6.627-5.373-12-12-12z",
                    url: "#",
                    hoverColor: "hover:text-gray-300"
                  }
                ].map((social) => (
                  <motion.a
                    key={social.name}
                    href={social.url}
                    target="_blank"
                    rel="noopener noreferrer"
                    whileHover={{ scale: 1.15, y: -2 }}
                    className={`w-11 h-11 bg-gray-900 border border-gray-600 rounded-xl flex items-center justify-center text-gray-400 hover:border-spxrk-500/50 hover:bg-gray-800 transition-all duration-300 group ${social.hoverColor}`}
                  >
                    <svg
                      className="w-5 h-5 transition-colors duration-300"
                      fill="currentColor"
                      viewBox="0 0 24 24"
                    >
                      <path d={social.icon} />
                    </svg>
                  </motion.a>
                ))}
              </div>
            </div>

            <div>
              <h4 className="text-lg font-semibold mb-4 text-spxrk-400">
                Services
              </h4>
              <ul className="space-y-3 text-muted-foreground">
                <li>
                  <a
                    href="#"
                    className="hover:text-spxrk-500 transition-colors"
                  >
                    AI Chatbots
                  </a>
                </li>
                <li>
                  <a
                    href="#"
                    className="hover:text-spxrk-500 transition-colors"
                  >
                    Virtual Assistants
                  </a>
                </li>
                <li>
                  <a
                    href="#"
                    className="hover:text-spxrk-500 transition-colors"
                  >
                    Custom Integration
                  </a>
                </li>
                <li>
                  <a
                    href="#"
                    className="hover:text-spxrk-500 transition-colors"
                  >
                    AI Consulting
                  </a>
                </li>
              </ul>
            </div>

            <div>
              <h4 className="text-lg font-semibold mb-4 text-spxrk-400">
                Company
              </h4>
              <ul className="space-y-3 text-muted-foreground">
                <li>
                  <a
                    href="#"
                    className="hover:text-spxrk-500 transition-colors"
                  >
                    About Us
                  </a>
                </li>
                <li>
                  <a
                    href="#"
                    className="hover:text-spxrk-500 transition-colors"
                  >
                    Careers
                  </a>
                </li>
                <li>
                  <a
                    href="#"
                    className="hover:text-spxrk-500 transition-colors"
                  >
                    Blog
                  </a>
                </li>
                <li>
                  <a
                    href="#"
                    className="hover:text-spxrk-500 transition-colors"
                  >
                    Contact
                  </a>
                </li>
              </ul>
            </div>
          </div>

          <div className="pt-8 border-t border-border text-center text-muted-foreground">
            <p>
              &copy; 2025 SPXRK. All rights reserved.
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}
